function toggle() {
	const menu = document.querySelector(".menu-links");
	const icon = document.querySelector(".hamburger-icon");
	menu.classList.toggle("clicked");
	icon.classList.toggle("clicked");
}

let sections = document.querySelectorAll("section");
// console.log(sections);
let navlinks = document.querySelectorAll("header nav a");
console.log(navlinks);
// window.onscroll = fun(); No need to call
// window.onscroll = function fun() { No need keep function name
// window.onscroll = function () {
window.onscroll = () => {
	let winY = window.scrollY;
	// console.log("Windows y values " + winY);
	sections.forEach((sec) => {
		let secTop = sec.offsetTop;
		let height = sec.offsetHeight;
		let id = sec.getAttribute("id");

		if (winY >= secTop && winY < secTop + height) {
			navlinks.forEach((links) => links.classList.remove("active"));
			let activeMenu = document.querySelectorAll(
				"header nav a[href*=" + id + "]"
			);
			activeMenu.forEach((link) => link.classList.add("active"));
		}
	});
	console.log(navlinks);
};

// navlinks.forEach((nav) => nav.classList.remove("active"));
// this.classList.add("active");
